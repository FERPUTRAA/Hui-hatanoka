.class public final Lg6/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Ljava/lang/String;

.field public final synthetic b:Ljava/util/Map;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Ljava/util/HashMap;

.field public final synthetic e:I

.field public final synthetic f:I

.field public final synthetic g:I

.field public final synthetic h:I

.field public final synthetic i:I

.field public final synthetic j:Lio/flutter/plugin/common/MethodChannel$Result;

.field public final synthetic k:Lg6/c;


# direct methods
.method public constructor <init>(Lg6/c;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ljava/util/HashMap;IIIIILio/flutter/plugin/common/MethodChannel$Result;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lg6/a;->k:Lg6/c;

    iput-object p2, p0, Lg6/a;->a:Ljava/lang/String;

    iput-object p3, p0, Lg6/a;->b:Ljava/util/Map;

    iput-object p4, p0, Lg6/a;->c:Ljava/lang/String;

    iput-object p5, p0, Lg6/a;->d:Ljava/util/HashMap;

    iput p6, p0, Lg6/a;->e:I

    iput p7, p0, Lg6/a;->f:I

    iput p8, p0, Lg6/a;->g:I

    iput p9, p0, Lg6/a;->h:I

    iput p10, p0, Lg6/a;->i:I

    iput-object p11, p0, Lg6/a;->j:Lio/flutter/plugin/common/MethodChannel$Result;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 17

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget-object v2, v1, Lg6/a;->k:Lg6/c;

    .line 4
    .line 5
    iget-object v0, v1, Lg6/a;->a:Ljava/lang/String;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    const/4 v4, 0x0

    .line 9
    :try_start_0
    const-string v5, "file"

    .line 10
    .line 11
    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v5

    .line 15
    const/4 v6, 0x1

    .line 16
    if-eqz v5, :cond_0

    .line 17
    .line 18
    iget-object v0, v1, Lg6/a;->b:Ljava/util/Map;

    .line 19
    .line 20
    const-string v5, "path"

    .line 21
    .line 22
    invoke-interface {v0, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    move-object v10, v0

    .line 27
    check-cast v10, Ljava/lang/String;

    .line 28
    .line 29
    iget-object v7, v1, Lg6/a;->k:Lg6/c;

    .line 30
    .line 31
    iget-object v8, v1, Lg6/a;->c:Ljava/lang/String;

    .line 32
    .line 33
    iget-object v9, v1, Lg6/a;->d:Ljava/util/HashMap;

    .line 34
    .line 35
    iget v11, v1, Lg6/a;->e:I

    .line 36
    .line 37
    iget v12, v1, Lg6/a;->f:I

    .line 38
    .line 39
    iget v13, v1, Lg6/a;->g:I

    .line 40
    .line 41
    iget v14, v1, Lg6/a;->h:I

    .line 42
    .line 43
    iget v15, v1, Lg6/a;->i:I

    .line 44
    .line 45
    invoke-static/range {v7 .. v15}, Lg6/c;->a(Lg6/c;Ljava/lang/String;Ljava/util/HashMap;Ljava/lang/String;IIIII)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    :goto_0
    move v4, v6

    .line 50
    goto :goto_1

    .line 51
    :cond_0
    const-string v5, "data"

    .line 52
    .line 53
    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    if-eqz v0, :cond_1

    .line 58
    .line 59
    iget-object v7, v1, Lg6/a;->c:Ljava/lang/String;

    .line 60
    .line 61
    iget-object v8, v1, Lg6/a;->d:Ljava/util/HashMap;

    .line 62
    .line 63
    iget v9, v1, Lg6/a;->e:I

    .line 64
    .line 65
    iget v10, v1, Lg6/a;->f:I

    .line 66
    .line 67
    iget v11, v1, Lg6/a;->g:I

    .line 68
    .line 69
    iget v12, v1, Lg6/a;->h:I

    .line 70
    .line 71
    iget v13, v1, Lg6/a;->i:I

    .line 72
    .line 73
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 74
    .line 75
    .line 76
    invoke-static/range {v7 .. v13}, Lg6/c;->b(Ljava/lang/String;Ljava/util/HashMap;IIIII)[B

    .line 77
    .line 78
    .line 79
    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 80
    goto :goto_0

    .line 81
    :catch_0
    move-exception v0

    .line 82
    goto :goto_2

    .line 83
    :cond_1
    move-object v0, v3

    .line 84
    :goto_1
    move-object/from16 v16, v3

    .line 85
    .line 86
    move-object v3, v0

    .line 87
    move-object/from16 v0, v16

    .line 88
    .line 89
    :goto_2
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 90
    .line 91
    .line 92
    new-instance v2, Lg6/b;

    .line 93
    .line 94
    iget-object v5, v1, Lg6/a;->j:Lio/flutter/plugin/common/MethodChannel$Result;

    .line 95
    .line 96
    invoke-direct {v2, v4, v5, v0, v3}, Lg6/b;-><init>(ZLio/flutter/plugin/common/MethodChannel$Result;Ljava/lang/Exception;Ljava/io/Serializable;)V

    .line 97
    .line 98
    .line 99
    new-instance v0, Landroid/os/Handler;

    .line 100
    .line 101
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 102
    .line 103
    .line 104
    move-result-object v3

    .line 105
    invoke-direct {v0, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 106
    .line 107
    .line 108
    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 109
    .line 110
    .line 111
    return-void
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
.end method
