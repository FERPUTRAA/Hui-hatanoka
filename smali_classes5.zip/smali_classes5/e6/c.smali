.class public interface abstract Le6/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract onResume()V
.end method
