.class public interface abstract Li6/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/media/MediaPlayer;)V
.end method

.method public abstract b(Lxyz/luan/audioplayers/player/k;)V
.end method
