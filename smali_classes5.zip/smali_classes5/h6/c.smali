.class public final synthetic Lh6/c;
.super Lkotlin/jvm/internal/FunctionReferenceImpl;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# direct methods
.method public constructor <init>(Ljava/lang/Object;)V
    .locals 7

    .line 1
    const-string v5, "methodHandler(Lio/flutter/plugin/common/MethodCall;Lio/flutter/plugin/common/MethodChannel$Result;)V"

    .line 2
    .line 3
    const/4 v6, 0x0

    .line 4
    const/4 v1, 0x2

    .line 5
    const-class v3, Lh6/e;

    .line 6
    .line 7
    const-string v4, "methodHandler"

    .line 8
    .line 9
    move-object v0, p0

    .line 10
    move-object v2, p1

    .line 11
    invoke-direct/range {v0 .. v6}, Lkotlin/jvm/internal/FunctionReferenceImpl;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 12
    .line 13
    .line 14
    return-void
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lio/flutter/plugin/common/MethodCall;

    check-cast p2, Lio/flutter/plugin/common/MethodChannel$Result;

    invoke-virtual {p0, p1, p2}, Lh6/c;->invoke(Lio/flutter/plugin/common/MethodCall;Lio/flutter/plugin/common/MethodChannel$Result;)V

    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p1
.end method

.method public final invoke(Lio/flutter/plugin/common/MethodCall;Lio/flutter/plugin/common/MethodChannel$Result;)V
    .locals 13

    const/4 v0, 0x0

    const/4 v1, 0x1

    const-string v2, "p0"

    invoke-static {p1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "p1"

    invoke-static {p2, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 2
    iget-object v2, p0, Lkotlin/jvm/internal/CallableReference;->receiver:Ljava/lang/Object;

    check-cast v2, Lh6/e;

    .line 3
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    const-string v3, "AndroidAudioError"

    const-string v4, "playerId"

    invoke-virtual {p1, v4}, Lio/flutter/plugin/common/MethodCall;->argument(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    if-nez v4, :cond_0

    goto/16 :goto_7

    .line 5
    :cond_0
    iget-object v5, p1, Lio/flutter/plugin/common/MethodCall;->method:Ljava/lang/String;

    const-string v6, "create"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    iget-object v6, v2, Lh6/e;->e:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v7, 0x0

    if-eqz v5, :cond_3

    .line 6
    new-instance p1, Lh6/f;

    new-instance v0, Lio/flutter/plugin/common/EventChannel;

    iget-object v3, v2, Lh6/e;->c:Lio/flutter/plugin/common/BinaryMessenger;

    if-nez v3, :cond_1

    const-string v3, "binaryMessenger"

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v3, v7

    :cond_1
    const-string v5, "xyz.luan/audioplayers/events/"

    invoke-virtual {v5, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v0, v3, v5}, Lio/flutter/plugin/common/EventChannel;-><init>(Lio/flutter/plugin/common/BinaryMessenger;Ljava/lang/String;)V

    invoke-direct {p1, v0}, Lh6/f;-><init>(Lio/flutter/plugin/common/EventChannel;)V

    .line 7
    new-instance v0, Lxyz/luan/audioplayers/player/n;

    iget-object v3, v2, Lh6/e;->f:Lh6/a;

    invoke-static {v3}, Lh6/a;->b(Lh6/a;)Lh6/a;

    move-result-object v3

    iget-object v5, v2, Lh6/e;->d:Lcom/faceunity/core/faceunity/p;

    if-nez v5, :cond_2

    const-string v5, "soundPoolManager"

    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_0

    :cond_2
    move-object v7, v5

    :goto_0
    invoke-direct {v0, v2, p1, v3, v7}, Lxyz/luan/audioplayers/player/n;-><init>(Lh6/e;Lh6/f;Lh6/a;Lcom/faceunity/core/faceunity/p;)V

    invoke-virtual {v6, v4, v0}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {p2, p1}, Lio/flutter/plugin/common/MethodChannel$Result;->success(Ljava/lang/Object;)V

    goto/16 :goto_7

    .line 9
    :cond_3
    invoke-virtual {v6, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lxyz/luan/audioplayers/player/n;

    if-eqz v2, :cond_31

    :try_start_0
    iget-object v5, v2, Lxyz/luan/audioplayers/player/n;->b:Lh6/f;

    .line 10
    iget-object v8, p1, Lio/flutter/plugin/common/MethodCall;->method:Ljava/lang/String;

    if-eqz v8, :cond_30

    invoke-virtual {v8}, Ljava/lang/String;->hashCode()I

    move-result v9
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-string v10, "message is required"

    const-string v11, "message"

    const/16 v12, 0x2e

    sparse-switch v9, :sswitch_data_0

    goto/16 :goto_5

    :sswitch_0
    :try_start_1
    const-string v4, "setReleaseMode"

    invoke-virtual {v8, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4

    goto/16 :goto_5

    .line 11
    :cond_4
    const-string v4, "releaseMode"

    .line 12
    invoke-virtual {p1, v4}, Lio/flutter/plugin/common/MethodCall;->argument(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    if-nez p1, :cond_5

    goto :goto_1

    .line 13
    :cond_5
    new-array v4, v1, [C

    aput-char v12, v4, v0

    invoke-static {p1, v4}, Lkotlin/text/StringsKt;->I(Ljava/lang/String;[C)Ljava/util/List;

    move-result-object p1

    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-static {p1}, Lv5/d;->t(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lh6/h;->valueOf(Ljava/lang/String;)Lh6/h;

    move-result-object v7

    :goto_1
    if-eqz v7, :cond_7

    .line 14
    const-string p1, "value"

    invoke-static {v7, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    iget-object p1, v2, Lxyz/luan/audioplayers/player/n;->j:Lh6/h;

    if-eq p1, v7, :cond_2c

    .line 16
    iput-object v7, v2, Lxyz/luan/audioplayers/player/n;->j:Lh6/h;

    .line 17
    iget-boolean p1, v2, Lxyz/luan/audioplayers/player/n;->l:Z

    if-nez p1, :cond_2c

    .line 18
    iget-object p1, v2, Lxyz/luan/audioplayers/player/n;->e:Lxyz/luan/audioplayers/player/g;

    if-eqz p1, :cond_2c

    .line 19
    sget-object v2, Lh6/h;->LOOP:Lh6/h;

    if-ne v7, v2, :cond_6

    move v0, v1

    .line 20
    :cond_6
    invoke-interface {p1, v0}, Lxyz/luan/audioplayers/player/g;->d(Z)V

    goto/16 :goto_4

    .line 21
    :cond_7
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "releaseMode is required"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :catch_0
    move-exception p1

    goto/16 :goto_6

    .line 22
    :sswitch_1
    const-string v0, "setAudioContext"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8

    goto/16 :goto_5

    .line 23
    :cond_8
    invoke-static {p1}, Lv5/d;->b(Lio/flutter/plugin/common/MethodCall;)Lh6/a;

    move-result-object p1

    .line 24
    invoke-virtual {v2, p1}, Lxyz/luan/audioplayers/player/n;->l(Lh6/a;)V

    goto/16 :goto_4

    .line 25
    :sswitch_2
    const-string v0, "setSourceBytes"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_9

    goto/16 :goto_5

    .line 26
    :cond_9
    const-string v0, "bytes"

    invoke-virtual {p1, v0}, Lio/flutter/plugin/common/MethodCall;->argument(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [B

    if-eqz p1, :cond_a

    .line 27
    new-instance v0, Li6/b;

    invoke-direct {v0, p1}, Li6/b;-><init>([B)V

    invoke-virtual {v2, v0}, Lxyz/luan/audioplayers/player/n;->i(Li6/c;)V

    goto/16 :goto_4

    .line 28
    :cond_a
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "bytes are required"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 29
    :sswitch_3
    const-string p1, "dispose"

    invoke-virtual {v8, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_b

    goto/16 :goto_5

    .line 30
    :cond_b
    invoke-virtual {v2}, Lxyz/luan/audioplayers/player/n;->e()V

    .line 31
    iget-object p1, v5, Lh6/f;->b:Lio/flutter/plugin/common/EventChannel$EventSink;

    if-eqz p1, :cond_c

    .line 32
    invoke-interface {p1}, Lio/flutter/plugin/common/EventChannel$EventSink;->endOfStream()V

    .line 33
    iput-object v7, v5, Lh6/f;->b:Lio/flutter/plugin/common/EventChannel$EventSink;

    .line 34
    :cond_c
    iget-object p1, v5, Lh6/f;->a:Lio/flutter/plugin/common/EventChannel;

    invoke-virtual {p1, v7}, Lio/flutter/plugin/common/EventChannel;->setStreamHandler(Lio/flutter/plugin/common/EventChannel$StreamHandler;)V

    .line 35
    invoke-virtual {v6, v4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_4

    .line 36
    :sswitch_4
    const-string p1, "release"

    invoke-virtual {v8, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_d

    goto/16 :goto_5

    .line 37
    :cond_d
    invoke-virtual {v2}, Lxyz/luan/audioplayers/player/n;->e()V

    goto/16 :goto_4

    .line 38
    :sswitch_5
    const-string v0, "emitError"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_e

    goto/16 :goto_5

    .line 39
    :cond_e
    const-string v0, "code"

    invoke-virtual {p1, v0}, Lio/flutter/plugin/common/MethodCall;->argument(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-eqz v0, :cond_10

    .line 40
    invoke-virtual {p1, v11}, Lio/flutter/plugin/common/MethodCall;->argument(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    if-eqz p1, :cond_f

    .line 41
    iget-object v4, v2, Lxyz/luan/audioplayers/player/n;->a:Lh6/e;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    const-string v4, "player"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    iget-object v2, v5, Lh6/f;->b:Lio/flutter/plugin/common/EventChannel$EventSink;

    if-eqz v2, :cond_2c

    invoke-interface {v2, v0, p1, v7}, Lio/flutter/plugin/common/EventChannel$EventSink;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    goto/16 :goto_4

    .line 44
    :cond_f
    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-direct {p1, v10}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 45
    :cond_10
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "code is required"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 46
    :sswitch_6
    const-string v0, "setVolume"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_11

    goto/16 :goto_5

    .line 47
    :cond_11
    const-string v0, "volume"

    invoke-virtual {p1, v0}, Lio/flutter/plugin/common/MethodCall;->argument(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Double;

    if-eqz p1, :cond_13

    invoke-virtual {p1}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v4

    double-to-float p1, v4

    .line 48
    iget v0, v2, Lxyz/luan/audioplayers/player/n;->g:F

    cmpg-float v0, v0, p1

    if-nez v0, :cond_12

    goto/16 :goto_4

    .line 49
    :cond_12
    iput p1, v2, Lxyz/luan/audioplayers/player/n;->g:F

    .line 50
    iget-boolean v0, v2, Lxyz/luan/audioplayers/player/n;->l:Z

    if-nez v0, :cond_2c

    .line 51
    iget-object v0, v2, Lxyz/luan/audioplayers/player/n;->e:Lxyz/luan/audioplayers/player/g;

    if-eqz v0, :cond_2c

    iget v2, v2, Lxyz/luan/audioplayers/player/n;->h:F

    invoke-static {v0, p1, v2}, Lxyz/luan/audioplayers/player/n;->j(Lxyz/luan/audioplayers/player/g;FF)V

    goto/16 :goto_4

    .line 52
    :cond_13
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "volume is required"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 53
    :sswitch_7
    const-string p1, "pause"

    invoke-virtual {v8, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_14

    goto/16 :goto_5

    .line 54
    :cond_14
    invoke-virtual {v2}, Lxyz/luan/audioplayers/player/n;->d()V

    goto/16 :goto_4

    .line 55
    :sswitch_8
    const-string p1, "getDuration"

    invoke-virtual {v8, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_15

    goto/16 :goto_5

    .line 56
    :cond_15
    iget-boolean p1, v2, Lxyz/luan/audioplayers/player/n;->m:Z

    if-eqz p1, :cond_16

    iget-object p1, v2, Lxyz/luan/audioplayers/player/n;->e:Lxyz/luan/audioplayers/player/g;

    if-eqz p1, :cond_16

    invoke-interface {p1}, Lxyz/luan/audioplayers/player/g;->getDuration()Ljava/lang/Integer;

    move-result-object v7

    .line 57
    :cond_16
    invoke-interface {p2, v7}, Lio/flutter/plugin/common/MethodChannel$Result;->success(Ljava/lang/Object;)V

    goto/16 :goto_7

    .line 58
    :sswitch_9
    const-string p1, "stop"

    invoke-virtual {v8, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_17

    goto/16 :goto_5

    .line 59
    :cond_17
    invoke-virtual {v2}, Lxyz/luan/audioplayers/player/n;->k()V

    goto/16 :goto_4

    .line 60
    :sswitch_a
    const-string v0, "seek"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_18

    goto/16 :goto_5

    .line 61
    :cond_18
    const-string v0, "position"

    invoke-virtual {p1, v0}, Lio/flutter/plugin/common/MethodCall;->argument(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Integer;

    if-eqz p1, :cond_1c

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    .line 62
    iget-boolean v0, v2, Lxyz/luan/audioplayers/player/n;->m:Z

    if-eqz v0, :cond_1b

    iget-object v0, v2, Lxyz/luan/audioplayers/player/n;->e:Lxyz/luan/audioplayers/player/g;

    if-eqz v0, :cond_19

    invoke-interface {v0}, Lxyz/luan/audioplayers/player/g;->m()Z

    move-result v0

    if-ne v0, v1, :cond_19

    goto :goto_2

    .line 63
    :cond_19
    iget-object v0, v2, Lxyz/luan/audioplayers/player/n;->e:Lxyz/luan/audioplayers/player/g;

    if-eqz v0, :cond_1a

    invoke-interface {v0, p1}, Lxyz/luan/audioplayers/player/g;->f(I)V

    :cond_1a
    const/4 p1, -0x1

    .line 64
    :cond_1b
    :goto_2
    iput p1, v2, Lxyz/luan/audioplayers/player/n;->o:I

    goto/16 :goto_4

    .line 65
    :cond_1c
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "position is required"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 66
    :sswitch_b
    const-string v4, "setSourceUrl"

    invoke-virtual {v8, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_1d

    goto/16 :goto_5

    .line 67
    :cond_1d
    const-string v4, "url"

    invoke-virtual {p1, v4}, Lio/flutter/plugin/common/MethodCall;->argument(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    if-eqz v4, :cond_1f

    .line 68
    const-string v5, "isLocal"

    invoke-virtual {p1, v5}, Lio/flutter/plugin/common/MethodCall;->argument(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    if-eqz p1, :cond_1e

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 69
    :cond_1e
    :try_start_2
    new-instance p1, Li6/d;

    invoke-direct {p1, v4, v0}, Li6/d;-><init>(Ljava/lang/String;Z)V

    invoke-virtual {v2, p1}, Lxyz/luan/audioplayers/player/n;->i(Li6/c;)V
    :try_end_2
    .catch Ljava/io/FileNotFoundException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto/16 :goto_4

    :catch_1
    move-exception p1

    .line 70
    :try_start_3
    const-string v0, "Failed to set source. For troubleshooting, see: https://github.com/bluefireteam/audioplayers/blob/main/troubleshooting.md"

    .line 71
    invoke-interface {p2, v3, v0, p1}, Lio/flutter/plugin/common/MethodChannel$Result;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    goto/16 :goto_7

    .line 72
    :cond_1f
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "url is required"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 73
    :sswitch_c
    const-string v0, "setPlaybackRate"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_20

    goto/16 :goto_5

    .line 74
    :cond_20
    const-string v0, "playbackRate"

    invoke-virtual {p1, v0}, Lio/flutter/plugin/common/MethodCall;->argument(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Double;

    if-eqz p1, :cond_22

    invoke-virtual {p1}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v4

    double-to-float p1, v4

    .line 75
    iget v0, v2, Lxyz/luan/audioplayers/player/n;->i:F

    cmpg-float v0, v0, p1

    if-nez v0, :cond_21

    goto/16 :goto_4

    .line 76
    :cond_21
    iput p1, v2, Lxyz/luan/audioplayers/player/n;->i:F

    .line 77
    iget-boolean v0, v2, Lxyz/luan/audioplayers/player/n;->n:Z

    if-eqz v0, :cond_2c

    .line 78
    iget-object v0, v2, Lxyz/luan/audioplayers/player/n;->e:Lxyz/luan/audioplayers/player/g;

    if-eqz v0, :cond_2c

    invoke-interface {v0, p1}, Lxyz/luan/audioplayers/player/g;->n(F)V

    goto/16 :goto_4

    .line 79
    :cond_22
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "playbackRate is required"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 80
    :sswitch_d
    const-string p1, "resume"

    invoke-virtual {v8, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_23

    goto/16 :goto_5

    .line 81
    :cond_23
    iget-boolean p1, v2, Lxyz/luan/audioplayers/player/n;->n:Z

    if-nez p1, :cond_2c

    iget-boolean p1, v2, Lxyz/luan/audioplayers/player/n;->l:Z

    if-nez p1, :cond_2c

    .line 82
    iput-boolean v1, v2, Lxyz/luan/audioplayers/player/n;->n:Z

    .line 83
    iget-object p1, v2, Lxyz/luan/audioplayers/player/n;->e:Lxyz/luan/audioplayers/player/g;

    if-nez p1, :cond_24

    .line 84
    invoke-virtual {v2}, Lxyz/luan/audioplayers/player/n;->b()Lxyz/luan/audioplayers/player/g;

    move-result-object p1

    .line 85
    iput-object p1, v2, Lxyz/luan/audioplayers/player/n;->e:Lxyz/luan/audioplayers/player/g;

    .line 86
    iget-object v0, v2, Lxyz/luan/audioplayers/player/n;->f:Li6/c;

    if-eqz v0, :cond_2c

    .line 87
    invoke-interface {p1, v0}, Lxyz/luan/audioplayers/player/g;->e(Li6/c;)V

    .line 88
    invoke-virtual {v2, p1}, Lxyz/luan/audioplayers/player/n;->a(Lxyz/luan/audioplayers/player/g;)V

    goto/16 :goto_4

    .line 89
    :cond_24
    iget-boolean p1, v2, Lxyz/luan/audioplayers/player/n;->m:Z

    if-eqz p1, :cond_2c

    .line 90
    invoke-virtual {v2}, Lxyz/luan/audioplayers/player/n;->f()V

    goto/16 :goto_4

    .line 91
    :sswitch_e
    const-string v0, "emitLog"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_25

    goto/16 :goto_5

    .line 92
    :cond_25
    invoke-virtual {p1, v11}, Lio/flutter/plugin/common/MethodCall;->argument(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    if-eqz p1, :cond_26

    .line 93
    invoke-virtual {v2, p1}, Lxyz/luan/audioplayers/player/n;->c(Ljava/lang/String;)V

    goto/16 :goto_4

    .line 94
    :cond_26
    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-direct {p1, v10}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 95
    :sswitch_f
    const-string v0, "setBalance"

    invoke-virtual {v8, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_27

    goto/16 :goto_5

    .line 96
    :cond_27
    const-string v0, "balance"

    invoke-virtual {p1, v0}, Lio/flutter/plugin/common/MethodCall;->argument(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Double;

    if-eqz p1, :cond_29

    invoke-virtual {p1}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v4

    double-to-float p1, v4

    .line 97
    iget v0, v2, Lxyz/luan/audioplayers/player/n;->h:F

    cmpg-float v0, v0, p1

    if-nez v0, :cond_28

    goto :goto_4

    .line 98
    :cond_28
    iput p1, v2, Lxyz/luan/audioplayers/player/n;->h:F

    .line 99
    iget-boolean v0, v2, Lxyz/luan/audioplayers/player/n;->l:Z

    if-nez v0, :cond_2c

    .line 100
    iget-object v0, v2, Lxyz/luan/audioplayers/player/n;->e:Lxyz/luan/audioplayers/player/g;

    if-eqz v0, :cond_2c

    iget v2, v2, Lxyz/luan/audioplayers/player/n;->g:F

    invoke-static {v0, v2, p1}, Lxyz/luan/audioplayers/player/n;->j(Lxyz/luan/audioplayers/player/g;FF)V

    goto :goto_4

    .line 101
    :cond_29
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "balance is required"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 102
    :sswitch_10
    const-string v4, "setPlayerMode"

    invoke-virtual {v8, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_2a

    goto :goto_5

    .line 103
    :cond_2a
    const-string v4, "playerMode"

    .line 104
    invoke-virtual {p1, v4}, Lio/flutter/plugin/common/MethodCall;->argument(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    if-nez p1, :cond_2b

    goto :goto_3

    .line 105
    :cond_2b
    new-array v4, v1, [C

    aput-char v12, v4, v0

    invoke-static {p1, v4}, Lkotlin/text/StringsKt;->I(Ljava/lang/String;[C)Ljava/util/List;

    move-result-object p1

    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-static {p1}, Lv5/d;->t(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lh6/g;->valueOf(Ljava/lang/String;)Lh6/g;

    move-result-object v7

    :goto_3
    if-eqz v7, :cond_2d

    .line 106
    invoke-virtual {v2, v7}, Lxyz/luan/audioplayers/player/n;->g(Lh6/g;)V

    .line 107
    :cond_2c
    :goto_4
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {p2, p1}, Lio/flutter/plugin/common/MethodChannel$Result;->success(Ljava/lang/Object;)V

    goto :goto_7

    .line 108
    :cond_2d
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "playerMode is required"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 109
    :sswitch_11
    const-string p1, "getCurrentPosition"

    invoke-virtual {v8, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_2e

    goto :goto_5

    .line 110
    :cond_2e
    iget-boolean p1, v2, Lxyz/luan/audioplayers/player/n;->m:Z

    if-eqz p1, :cond_2f

    iget-object p1, v2, Lxyz/luan/audioplayers/player/n;->e:Lxyz/luan/audioplayers/player/g;

    if-eqz p1, :cond_2f

    invoke-interface {p1}, Lxyz/luan/audioplayers/player/g;->getCurrentPosition()Ljava/lang/Integer;

    move-result-object v7

    .line 111
    :cond_2f
    invoke-interface {p2, v7}, Lio/flutter/plugin/common/MethodChannel$Result;->success(Ljava/lang/Object;)V

    goto :goto_7

    .line 112
    :cond_30
    :goto_5
    invoke-interface {p2}, Lio/flutter/plugin/common/MethodChannel$Result;->notImplemented()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    goto :goto_7

    .line 113
    :goto_6
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-interface {p2, v3, v0, p1}, Lio/flutter/plugin/common/MethodChannel$Result;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    :goto_7
    return-void

    .line 114
    :cond_31
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Player has not yet been created or has already been disposed."

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    nop

    :sswitch_data_0
    .sparse-switch
        -0x68b9fc74 -> :sswitch_11
        -0x66b209da -> :sswitch_10
        -0x62f907e6 -> :sswitch_f
        -0x612cd98f -> :sswitch_e
        -0x37b237d3 -> :sswitch_d
        -0x17fa60e3 -> :sswitch_c
        -0x97aa2ee -> :sswitch_b
        0x35ce78 -> :sswitch_a
        0x360802 -> :sswitch_9
        0x51e8b0a -> :sswitch_8
        0x65825f6 -> :sswitch_7
        0x27f73e1c -> :sswitch_6
        0x36423df5 -> :sswitch_5
        0x41012807 -> :sswitch_4
        0x63a5261f -> :sswitch_3
        0x6999fb4e -> :sswitch_2
        0x7164e27b -> :sswitch_1
        0x7cf03488 -> :sswitch_0
    .end sparse-switch
.end method
