.class public final Lxyz/luan/audioplayers/player/j;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field final synthetic $soundPoolPlayer:Lxyz/luan/audioplayers/player/k;

.field final synthetic $start:J

.field final synthetic $value:Li6/d;

.field label:I

.field final synthetic this$0:Lxyz/luan/audioplayers/player/k;


# direct methods
.method public constructor <init>(Li6/d;Lxyz/luan/audioplayers/player/k;Lxyz/luan/audioplayers/player/k;JLkotlin/coroutines/Continuation;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li6/d;",
            "Lxyz/luan/audioplayers/player/k;",
            "Lxyz/luan/audioplayers/player/k;",
            "J",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lxyz/luan/audioplayers/player/j;",
            ">;)V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, Lxyz/luan/audioplayers/player/j;->$value:Li6/d;

    .line 2
    .line 3
    iput-object p2, p0, Lxyz/luan/audioplayers/player/j;->this$0:Lxyz/luan/audioplayers/player/k;

    .line 4
    .line 5
    iput-object p3, p0, Lxyz/luan/audioplayers/player/j;->$soundPoolPlayer:Lxyz/luan/audioplayers/player/k;

    .line 6
    .line 7
    iput-wide p4, p0, Lxyz/luan/audioplayers/player/j;->$start:J

    .line 8
    .line 9
    const/4 p1, 0x2

    .line 10
    invoke-direct {p0, p1, p6}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 11
    .line 12
    .line 13
    return-void
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance p1, Lxyz/luan/audioplayers/player/j;

    iget-object v1, p0, Lxyz/luan/audioplayers/player/j;->$value:Li6/d;

    iget-object v2, p0, Lxyz/luan/audioplayers/player/j;->this$0:Lxyz/luan/audioplayers/player/k;

    iget-object v3, p0, Lxyz/luan/audioplayers/player/j;->$soundPoolPlayer:Lxyz/luan/audioplayers/player/k;

    iget-wide v4, p0, Lxyz/luan/audioplayers/player/j;->$start:J

    move-object v0, p1

    move-object v6, p2

    invoke-direct/range {v0 .. v6}, Lxyz/luan/audioplayers/player/j;-><init>(Li6/d;Lxyz/luan/audioplayers/player/k;Lxyz/luan/audioplayers/player/k;JLkotlin/coroutines/Continuation;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/x;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lxyz/luan/audioplayers/player/j;->invoke(Lkotlinx/coroutines/x;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/x;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/x;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 2
    invoke-virtual {p0, p1, p2}, Lxyz/luan/audioplayers/player/j;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object p1

    check-cast p1, Lxyz/luan/audioplayers/player/j;

    sget-object p2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {p1, p2}, Lxyz/luan/audioplayers/player/j;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    iget v0, p0, Lxyz/luan/audioplayers/player/j;->label:I

    .line 5
    .line 6
    if-nez v0, :cond_3

    .line 7
    .line 8
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    iget-object p1, p0, Lxyz/luan/audioplayers/player/j;->$value:Li6/d;

    .line 12
    .line 13
    iget-boolean v0, p1, Li6/d;->b:Z

    .line 14
    .line 15
    iget-object p1, p1, Li6/d;->a:Ljava/lang/String;

    .line 16
    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    const-string v0, "file://"

    .line 20
    .line 21
    invoke-static {p1, v0}, Lkotlin/text/StringsKt;->B(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    :goto_0
    move-object v3, p1

    .line 26
    goto :goto_3

    .line 27
    :cond_0
    invoke-static {p1}, Ljava/net/URI;->create(Ljava/lang/String;)Ljava/net/URI;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    invoke-virtual {p1}, Ljava/net/URI;->toURL()Ljava/net/URL;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    const-string v0, "toURL(...)"

    .line 36
    .line 37
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    .line 41
    .line 42
    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 43
    .line 44
    .line 45
    invoke-virtual {p1}, Ljava/net/URL;->openStream()Ljava/io/InputStream;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    const/16 v1, 0x1000

    .line 50
    .line 51
    :try_start_0
    new-array v1, v1, [B

    .line 52
    .line 53
    :goto_1
    invoke-virtual {p1, v1}, Ljava/io/InputStream;->read([B)I

    .line 54
    .line 55
    .line 56
    move-result v2

    .line 57
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 58
    .line 59
    .line 60
    move-result-object v3

    .line 61
    const/4 v4, 0x0

    .line 62
    if-lez v2, :cond_1

    .line 63
    .line 64
    goto :goto_2

    .line 65
    :cond_1
    move-object v3, v4

    .line 66
    :goto_2
    if-eqz v3, :cond_2

    .line 67
    .line 68
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 69
    .line 70
    .line 71
    move-result v2

    .line 72
    const/4 v3, 0x0

    .line 73
    invoke-virtual {v0, v1, v3, v2}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 74
    .line 75
    .line 76
    goto :goto_1

    .line 77
    :catchall_0
    move-exception v0

    .line 78
    goto :goto_4

    .line 79
    :cond_2
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 80
    .line 81
    invoke-static {p1, v4}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 82
    .line 83
    .line 84
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    const-string v0, "toByteArray(...)"

    .line 89
    .line 90
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    const-string v0, "sound"

    .line 94
    .line 95
    const-string v1, ""

    .line 96
    .line 97
    invoke-static {v0, v1}, Ljava/io/File;->createTempFile(Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    new-instance v1, Ljava/io/FileOutputStream;

    .line 102
    .line 103
    invoke-direct {v1, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 104
    .line 105
    .line 106
    :try_start_1
    invoke-virtual {v1, p1}, Ljava/io/FileOutputStream;->write([B)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v0}, Ljava/io/File;->deleteOnExit()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 110
    .line 111
    .line 112
    invoke-static {v1, v4}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 113
    .line 114
    .line 115
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object p1

    .line 122
    const-string v0, "getAbsolutePath(...)"

    .line 123
    .line 124
    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 125
    .line 126
    .line 127
    goto :goto_0

    .line 128
    :goto_3
    iget-object v2, p0, Lxyz/luan/audioplayers/player/j;->this$0:Lxyz/luan/audioplayers/player/k;

    .line 129
    .line 130
    iget-object p1, v2, Lxyz/luan/audioplayers/player/k;->c:Lk5/d;

    .line 131
    .line 132
    sget-object v0, Lkotlinx/coroutines/n0;->a:Lm5/f;

    .line 133
    .line 134
    sget-object v0, Lk5/p;->a:Lj5/c;

    .line 135
    .line 136
    new-instance v9, Lxyz/luan/audioplayers/player/i;

    .line 137
    .line 138
    iget-object v4, p0, Lxyz/luan/audioplayers/player/j;->$soundPoolPlayer:Lxyz/luan/audioplayers/player/k;

    .line 139
    .line 140
    iget-object v5, p0, Lxyz/luan/audioplayers/player/j;->$value:Li6/d;

    .line 141
    .line 142
    iget-wide v6, p0, Lxyz/luan/audioplayers/player/j;->$start:J

    .line 143
    .line 144
    const/4 v8, 0x0

    .line 145
    move-object v1, v9

    .line 146
    invoke-direct/range {v1 .. v8}, Lxyz/luan/audioplayers/player/i;-><init>(Lxyz/luan/audioplayers/player/k;Ljava/lang/String;Lxyz/luan/audioplayers/player/k;Li6/d;JLkotlin/coroutines/Continuation;)V

    .line 147
    .line 148
    .line 149
    const/4 v1, 0x2

    .line 150
    invoke-static {p1, v0, v9, v1}, Lkotlinx/coroutines/c0;->h(Lkotlinx/coroutines/x;Lkotlinx/coroutines/t;Lkotlin/jvm/functions/Function2;I)Lkotlinx/coroutines/v1;

    .line 151
    .line 152
    .line 153
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 154
    .line 155
    return-object p1

    .line 156
    :catchall_1
    move-exception p1

    .line 157
    :try_start_2
    throw p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 158
    :catchall_2
    move-exception v0

    .line 159
    invoke-static {v1, p1}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 160
    .line 161
    .line 162
    throw v0

    .line 163
    :goto_4
    :try_start_3
    throw v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    .line 164
    :catchall_3
    move-exception v1

    .line 165
    invoke-static {p1, v0}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 166
    .line 167
    .line 168
    throw v1

    .line 169
    :cond_3
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 170
    .line 171
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 172
    .line 173
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 174
    .line 175
    .line 176
    throw p1
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
.end method
