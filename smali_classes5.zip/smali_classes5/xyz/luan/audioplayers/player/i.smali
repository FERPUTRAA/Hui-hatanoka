.class public final Lxyz/luan/audioplayers/player/i;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field final synthetic $actualUrl:Ljava/lang/String;

.field final synthetic $soundPoolPlayer:Lxyz/luan/audioplayers/player/k;

.field final synthetic $start:J

.field final synthetic $value:Li6/d;

.field private synthetic L$0:Ljava/lang/Object;

.field label:I

.field final synthetic this$0:Lxyz/luan/audioplayers/player/k;


# direct methods
.method public constructor <init>(Lxyz/luan/audioplayers/player/k;Ljava/lang/String;Lxyz/luan/audioplayers/player/k;Li6/d;JLkotlin/coroutines/Continuation;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lxyz/luan/audioplayers/player/k;",
            "Ljava/lang/String;",
            "Lxyz/luan/audioplayers/player/k;",
            "Li6/d;",
            "J",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lxyz/luan/audioplayers/player/i;",
            ">;)V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, Lxyz/luan/audioplayers/player/i;->this$0:Lxyz/luan/audioplayers/player/k;

    .line 2
    .line 3
    iput-object p2, p0, Lxyz/luan/audioplayers/player/i;->$actualUrl:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p3, p0, Lxyz/luan/audioplayers/player/i;->$soundPoolPlayer:Lxyz/luan/audioplayers/player/k;

    .line 6
    .line 7
    iput-object p4, p0, Lxyz/luan/audioplayers/player/i;->$value:Li6/d;

    .line 8
    .line 9
    iput-wide p5, p0, Lxyz/luan/audioplayers/player/i;->$start:J

    .line 10
    .line 11
    const/4 p1, 0x2

    .line 12
    invoke-direct {p0, p1, p7}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 13
    .line 14
    .line 15
    return-void
    .line 16
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance v8, Lxyz/luan/audioplayers/player/i;

    iget-object v1, p0, Lxyz/luan/audioplayers/player/i;->this$0:Lxyz/luan/audioplayers/player/k;

    iget-object v2, p0, Lxyz/luan/audioplayers/player/i;->$actualUrl:Ljava/lang/String;

    iget-object v3, p0, Lxyz/luan/audioplayers/player/i;->$soundPoolPlayer:Lxyz/luan/audioplayers/player/k;

    iget-object v4, p0, Lxyz/luan/audioplayers/player/i;->$value:Li6/d;

    iget-wide v5, p0, Lxyz/luan/audioplayers/player/i;->$start:J

    move-object v0, v8

    move-object v7, p2

    invoke-direct/range {v0 .. v7}, Lxyz/luan/audioplayers/player/i;-><init>(Lxyz/luan/audioplayers/player/k;Ljava/lang/String;Lxyz/luan/audioplayers/player/k;Li6/d;JLkotlin/coroutines/Continuation;)V

    iput-object p1, v8, Lxyz/luan/audioplayers/player/i;->L$0:Ljava/lang/Object;

    return-object v8
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lkotlinx/coroutines/x;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lxyz/luan/audioplayers/player/i;->invoke(Lkotlinx/coroutines/x;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/x;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/x;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 2
    invoke-virtual {p0, p1, p2}, Lxyz/luan/audioplayers/player/i;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object p1

    check-cast p1, Lxyz/luan/audioplayers/player/i;

    sget-object p2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {p1, p2}, Lxyz/luan/audioplayers/player/i;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    iget v0, p0, Lxyz/luan/audioplayers/player/i;->label:I

    .line 5
    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    iget-object p1, p0, Lxyz/luan/audioplayers/player/i;->L$0:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p1, Lkotlinx/coroutines/x;

    .line 14
    .line 15
    iget-object v0, p0, Lxyz/luan/audioplayers/player/i;->this$0:Lxyz/luan/audioplayers/player/k;

    .line 16
    .line 17
    iget-object v0, v0, Lxyz/luan/audioplayers/player/k;->a:Lxyz/luan/audioplayers/player/n;

    .line 18
    .line 19
    new-instance v1, Ljava/lang/StringBuilder;

    .line 20
    .line 21
    const-string v2, "Now loading "

    .line 22
    .line 23
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    iget-object v2, p0, Lxyz/luan/audioplayers/player/i;->$actualUrl:Ljava/lang/String;

    .line 27
    .line 28
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    invoke-virtual {v0, v1}, Lxyz/luan/audioplayers/player/n;->c(Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    iget-object v0, p0, Lxyz/luan/audioplayers/player/i;->this$0:Lxyz/luan/audioplayers/player/k;

    .line 39
    .line 40
    iget-object v0, v0, Lxyz/luan/audioplayers/player/k;->g:Lxyz/luan/audioplayers/player/l;

    .line 41
    .line 42
    iget-object v0, v0, Lxyz/luan/audioplayers/player/l;->a:Landroid/media/SoundPool;

    .line 43
    .line 44
    iget-object v1, p0, Lxyz/luan/audioplayers/player/i;->$actualUrl:Ljava/lang/String;

    .line 45
    .line 46
    const/4 v2, 0x1

    .line 47
    invoke-virtual {v0, v1, v2}, Landroid/media/SoundPool;->load(Ljava/lang/String;I)I

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    invoke-static {v0}, Lkotlin/coroutines/jvm/internal/Boxing;->boxInt(I)Ljava/lang/Integer;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    iget-object v2, p0, Lxyz/luan/audioplayers/player/i;->this$0:Lxyz/luan/audioplayers/player/k;

    .line 56
    .line 57
    iget-object v2, v2, Lxyz/luan/audioplayers/player/k;->g:Lxyz/luan/audioplayers/player/l;

    .line 58
    .line 59
    iget-object v2, v2, Lxyz/luan/audioplayers/player/l;->b:Ljava/util/Map;

    .line 60
    .line 61
    iget-object v3, p0, Lxyz/luan/audioplayers/player/i;->$soundPoolPlayer:Lxyz/luan/audioplayers/player/k;

    .line 62
    .line 63
    invoke-interface {v2, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    iget-object v1, p0, Lxyz/luan/audioplayers/player/i;->this$0:Lxyz/luan/audioplayers/player/k;

    .line 67
    .line 68
    invoke-static {v0}, Lkotlin/coroutines/jvm/internal/Boxing;->boxInt(I)Ljava/lang/Integer;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    iput-object v0, v1, Lxyz/luan/audioplayers/player/k;->d:Ljava/lang/Integer;

    .line 73
    .line 74
    iget-object v0, p0, Lxyz/luan/audioplayers/player/i;->this$0:Lxyz/luan/audioplayers/player/k;

    .line 75
    .line 76
    iget-object v0, v0, Lxyz/luan/audioplayers/player/k;->a:Lxyz/luan/audioplayers/player/n;

    .line 77
    .line 78
    new-instance v1, Ljava/lang/StringBuilder;

    .line 79
    .line 80
    const-string v2, "time to call load() for "

    .line 81
    .line 82
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    iget-object v2, p0, Lxyz/luan/audioplayers/player/i;->$value:Li6/d;

    .line 86
    .line 87
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 88
    .line 89
    .line 90
    const-string v2, ": "

    .line 91
    .line 92
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 96
    .line 97
    .line 98
    move-result-wide v2

    .line 99
    iget-wide v4, p0, Lxyz/luan/audioplayers/player/i;->$start:J

    .line 100
    .line 101
    sub-long/2addr v2, v4

    .line 102
    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 103
    .line 104
    .line 105
    const-string v2, " player="

    .line 106
    .line 107
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 108
    .line 109
    .line 110
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 111
    .line 112
    .line 113
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object p1

    .line 117
    invoke-virtual {v0, p1}, Lxyz/luan/audioplayers/player/n;->c(Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 121
    .line 122
    return-object p1

    .line 123
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 124
    .line 125
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 126
    .line 127
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 128
    .line 129
    .line 130
    throw p1
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
.end method
