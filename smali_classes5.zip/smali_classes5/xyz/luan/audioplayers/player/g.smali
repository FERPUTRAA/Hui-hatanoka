.class public interface abstract Lxyz/luan/audioplayers/player/g;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Lh6/a;)V
.end method

.method public abstract d(Z)V
.end method

.method public abstract e(Li6/c;)V
.end method

.method public abstract f(I)V
.end method

.method public abstract g(FF)V
.end method

.method public abstract getCurrentPosition()Ljava/lang/Integer;
.end method

.method public abstract getDuration()Ljava/lang/Integer;
.end method

.method public abstract m()Z
.end method

.method public abstract n(F)V
.end method

.method public abstract pause()V
.end method

.method public abstract prepare()V
.end method

.method public abstract release()V
.end method

.method public abstract reset()V
.end method

.method public abstract start()V
.end method

.method public abstract stop()V
.end method
