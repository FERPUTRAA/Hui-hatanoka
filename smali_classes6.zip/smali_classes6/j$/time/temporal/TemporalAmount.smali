.class public interface abstract Lj$/time/temporal/TemporalAmount;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract p(Lj$/time/temporal/m;)Lj$/time/temporal/m;
.end method

.method public abstract r(Lj$/time/Instant;)Lj$/time/temporal/m;
.end method
