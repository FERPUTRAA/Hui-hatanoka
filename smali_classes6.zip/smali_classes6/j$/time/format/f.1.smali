.class interface abstract Lj$/time/format/f;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract p(Lj$/time/format/z;Ljava/lang/StringBuilder;)Z
.end method

.method public abstract r(Lj$/time/format/w;Ljava/lang/CharSequence;I)I
.end method
